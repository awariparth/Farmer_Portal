package com.lti.service;

import org.springframework.stereotype.Service;

import com.lti.model.Bidder;

@Service
public interface IBidderService {
public void addBidder(Bidder bidder);
}
